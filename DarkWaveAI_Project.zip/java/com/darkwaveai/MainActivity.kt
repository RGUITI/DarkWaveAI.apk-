
package com.darkwaveai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : AppCompatActivity() {
    lateinit var wifiManager: WifiManager
    lateinit var listView: ListView
    lateinit var btnScan: Button
    lateinit var btnCrack: Button
    lateinit var btnGenerate: Button
    lateinit var langSwitch: Switch
    lateinit var networkList: List<ScanResult>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (! Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        listView = findViewById(R.id.listNetworks)
        btnScan = findViewById(R.id.btnScan)
        btnCrack = findViewById(R.id.btnCrack)
        btnGenerate = findViewById(R.id.btnGenerate)
        langSwitch = findViewById(R.id.switchLang)

        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE
        ), 1)

        btnScan.setOnClickListener {
            wifiManager.startScan()
            networkList = wifiManager.scanResults
            val ssids = networkList.map { it.SSID + " - " + it.capabilities }
            listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ssids)
        }

        btnCrack.setOnClickListener {
            val selected = listView.checkedItemPosition
            if (selected != ListView.INVALID_POSITION) {
                val ssid = networkList[selected].SSID
                val py = Python.getInstance()
                val module = py.getModule("cracker")
                val passwords = listOf("12345678", "password", "darkwave123")
                val result = module.callAttr("crack", ssid, passwords)
                Toast.makeText(this, "Found: $result", Toast.LENGTH_LONG).show()
            }
        }

        btnGenerate.setOnClickListener {
            val selected = listView.checkedItemPosition
            if (selected != ListView.INVALID_POSITION) {
                val ssid = networkList[selected].SSID
                val py = Python.getInstance()
                val module = py.getModule("generator")
                val generated = module.callAttr("generate", ssid, 8, 12)
                Toast.makeText(this, "Generated Passwords:\n$generated", Toast.LENGTH_LONG).show()
            }
        }
    }
}
