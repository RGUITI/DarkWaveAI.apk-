
def crack(ssid, wordlist):
    for pwd in wordlist:
        if simulate_connection(ssid, pwd):
            return pwd
    return "Not Found"

def simulate_connection(ssid, password):
    return password == "darkwave123"
