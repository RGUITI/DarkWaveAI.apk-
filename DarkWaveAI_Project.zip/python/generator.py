
import random
import string

def generate(ssid, min_len, max_len):
    passwords = []
    for _ in range(5):
        length = random.randint(min_len, max_len)
        pwd = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
        passwords.append(pwd)
    return '\n'.join(passwords)
